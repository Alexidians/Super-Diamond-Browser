import os
import shutil
import zipfile
import io
import importlib.util
import sys

# List of required modules and their installation names
REQUIRED_MODULES = {
    'requests': 'requests'
}

def check_module(module_name):
    """Check if a module is installed."""
    spec = importlib.util.find_spec(module_name)
    return spec is not None

def install_module(module_name):
    """Install a module using pip."""
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', module_name])

def download_zip(url):
    """Download the ZIP file from the given URL."""
    import requests
    response = requests.get(url)
    if response.status_code == 200:
        return io.BytesIO(response.content)
    else:
        response.raise_for_status()

def extract_zip(zip_data, extract_to='.'):
    """Extract the ZIP file and overwrite files in the current directory."""
    with zipfile.ZipFile(zip_data) as z:
        for member in z.namelist():
            # Skip extracting update.py
            if member == 'update.py':
                continue
            # Extract file or directory
            z.extract(member, extract_to)

def update_files():
    """Update files by downloading and extracting the latest version."""
    url = 'https://alexidians.github.io/Super-Diamond-Browser/python/Super-Diamond-Chrome-Python.zip'
    
    # Check and install required modules if not installed
    print('Checking required modules...')
    for module_name, install_name in REQUIRED_MODULES.items():
        if not check_module(module_name):
            print(f'{module_name} is not installed. Installing...')
            try:
                install_module(install_name)
            except Exception as e:
                print(f'Error installing {module_name}: {str(e)}')
                return
            print(f'{module_name} installed successfully.')
        else:
            print(f'{module_name} is already installed.')
    
    # Download the ZIP file
    print('Downloading update...')
    zip_data = download_zip(url)
    print('Download complete.')

    # Extract the ZIP file
    print('Extracting files...')
    extract_zip(zip_data)
    print('Extraction complete.')

    # Move extracted files to current directory, preserving data/ directory
    print('Updating files...')
    for root, dirs, files in os.walk('.'):
        for name in files:
            if name == 'update.py':
                continue
            src_file = os.path.join(root, name)
            dest_file = os.path.relpath(src_file, '.')
            if dest_file.startswith('data/'):
                continue
            os.makedirs(os.path.dirname(dest_file), exist_ok=True)
            shutil.move(src_file, dest_file)

    print('Update complete.')

if __name__ == '__main__':
    update_files()
