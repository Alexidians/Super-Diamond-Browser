import subprocess
import sys
import os
import time
import shutil
import json

def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

try:
    import selenium
except ImportError:
    print("Selenium not found. Installing...")
    install_package("selenium")
    import selenium

try:
    from webdriver_manager.chrome import ChromeDriverManager
except ImportError:
    print("webdriver_manager not found. Installing...")
    install_package("webdriver_manager")
    from webdriver_manager.chrome import ChromeDriverManager

try:
    import validators
except ImportError:
    print("validators not found. Installing...")
    install_package("validators")
    import validators
if not sys.platform.startswith('win'):
 try:
    import shlex
 except ImportError:
    print("shlex not found. Installing...")
    install_package("shlex")
    import shlex

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException

# Define the base data directory
base_data_dir = os.path.join(os.getcwd(), 'data')
profiles_dir = os.path.join(base_data_dir, 'profiles')
driver = None
# Ensure the profiles directory exists
os.makedirs(profiles_dir, exist_ok=True)

def list_profiles():
    return [name for name in os.listdir(profiles_dir) if os.path.isdir(os.path.join(profiles_dir, name))]

def create_profile(profile_name):
    profile_dir = os.path.join(profiles_dir, profile_name)
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)
        print(f"Profile '{profile_name}' created.")
        save_profile_settings(profile_name, {
          'homepage': os.path.join(os.path.dirname(os.path.abspath(__file__)), "files/pages/home.html").replace("\\", "/"),
          'arguments': [],
          'debugMode': False,
          'useDefaultArguments': True,
          'defaultExperiments': True,
          'enableDevtools': True,
          'incognito': False,
          'webdriverautomationdetectorfix': True
        })  # Initialize Default Settings
    else:
        print(f"Profile '{profile_name}' already exists.")

def delete_profile(profile_name):
    profile_dir = os.path.join(profiles_dir, profile_name)
    if os.path.exists(profile_dir):
        confirmation = input(f"Are you sure you want to delete the profile '{profile_name}'? This action cannot be undone. (yes/no): ")
        if confirmation.lower() == 'yes':
            shutil.rmtree(profile_dir)
            delete_profile_settings(profile_name)
            print(f"Profile '{profile_name}' deleted.")
        else:
            print("Deletion cancelled.")
    else:
        print(f"Profile '{profile_name}' does not exist.")

def select_profile():
    profiles = list_profiles()
    if not profiles:
        print("No profiles available. Please create a new profile.")
        return None
    print("Available profiles:")
    for i, profile in enumerate(profiles, 1):
        print(f"{i}. {profile}")
    choice = input("Select a profile by number: ")
    try:
        index = int(choice) - 1
        if 0 <= index < len(profiles):
            return profiles[index]
        else:
            print("Invalid selection.")
            return None
    except ValueError:
        print("Invalid input.")
        return None

def get_profile_settings(profile_name):
    profile_settings_file = os.path.join(profiles_dir, profile_name, 'settings.json')
    if os.path.exists(profile_settings_file):
        with open(profile_settings_file, 'r') as f:
            return json.load(f)
    else:
        return {}

def save_profile_settings(profile_name, settings):
    profile_dir = os.path.join(profiles_dir, profile_name)
    profile_settings_file = os.path.join(profile_dir, 'settings.json')
    with open(profile_settings_file, 'w') as f:
        json.dump(settings, f, indent=4)

def delete_profile_settings(profile_name):
    profile_settings_file = os.path.join(profiles_dir, profile_name, 'settings.json')
    if os.path.exists(profile_settings_file):
        os.remove(profile_settings_file)

def modify_profile_settings(profile_name):
    settings = get_profile_settings(profile_name)
    print(f"\nCurrent Settings for Profile '{profile_name}':")
    print(json.dumps(settings, indent=4))

    while True:
        print("\nModify Settings Menu:")
        print("1. Add Chrome command-line argument")
        print("2. Remove Chrome command-line argument")
        print("3. Toggle Debug Mode")
        print("4. Toggle Default Arguments")
        print("5. Toggle DevTools")
        print("6. Set Homepage")
        print("7. Toggle Default Experiments")
        print("8. Toggle Incognito")
        print("9. Toggle Web Driver Automation Detector Fix (prevents websites from thinking this webdriver is an automation)")
        print("10. Set user agent mask")
        print("11. Finish")
        choice = input("Choose an option: ")

        if choice == '1':
            argument = input("Enter the Chrome command-line argument (e.g., '--disable-infobars'): ")
            settings['arguments'] = settings.get('arguments', []) + [argument]
        elif choice == '2':
            if 'arguments' in settings:
                print("Current Chrome command-line arguments:")
                for i, arg in enumerate(settings['arguments'], 1):
                    print(f"{i}. {arg}")
                remove_choice = input("Select the argument number to remove: ")
                try:
                    index = int(remove_choice) - 1
                    if 0 <= index < len(settings['arguments']):
                        del settings['arguments'][index]
                        print("Argument removed.")
                    else:
                        print("Invalid argument number.")
                except ValueError:
                    print("Invalid input.")
        elif choice == '3':
            settings['debugMode'] = not settings.get('debugMode', False)
            if settings['debugMode']:
                print("Debug Mode enabled. You can now run code in the console.")
            else:
                print("Debug Mode disabled.")
        elif choice == '4':
            settings['useDefaultArguments'] = not settings.get('useDefaultArguments', True)
            if settings['useDefaultArguments']:
                print("Default arguments enabled.")
            else:
                print("Default arguments disabled.")
        elif choice == '5':
            settings['enableDevtools'] = not settings.get('enableDevtools', False)
            if settings['enableDevtools']:
                print("Devtools Enabled. now you can use devtools on pages.")
            else:
                print("Devtools Disabled. you can no longer use devtools on pages.")
        elif choice == '6':
            homepage_path = input("Enter the url for homepage. (use file:// protocol for files. enter ''default' to reset. 'chrome' for chrome homepage): ")
            if(homepage_path == "default"):
             settings['homepage'] = "file://" + os.path.join(os.path.dirname(os.path.abspath(__file__)), "files/pages/home.html").replace("\\", "/")
            elif(homepage_path == "chrome"):
             settings['homepage'] = "chrome://newtab"
            else:
             if(validators.url(homepage_path)):
              settings['homepage'] = homepage_path
              print("set homepage to " + homepage_path + " Sucesfully")
             else:
              print("The URL" + homepage_path + " is not valid")
        elif choice == '7':
            settings['defaultExperiments'] = not settings.get('defaultExperiments', False)
            if settings['defaultExperiments']:
                print("Default Experiments Enabled.")
            else:
                print("Default Experiments Disabled.")
        elif choice == '8':
            settings['incognito'] = not settings.get('incognito', False)
            if settings['incognito']:
                print("Incognito Enabled. now this profile will open with incognito.")
            else:
                print("Incognito Disabled. now this profile will open with normal chrome")
        elif choice == '9':
            settings['webdriverautomationdetectorfix'] = not settings.get('webdriverautomationfix', True)
            if settings['webdriverautomationdetectorfix']:
                print("Web Driver Automation Detector Fix Enabled. now this profile will no longer be detected as an webdriver automation.")
            else:
                print("Web Driver Automation Detector Fix Disabled. now this profile may be detected as a webdriver automation on some websites.")
        elif choice == '10':
            newuseragent = input("Set your new masked user agent (type '' to remove masking. if already none. will be ''): ")
            if newuseragent == "" and 'userAgent' in settings:
                del settings.userAgent
            else:
                settings["userAgent"] = newuseragent
        elif choice == '11':
            print("Saving modified settings...")
            save_profile_settings(profile_name, settings)
            break
        else:
            print("Invalid option. Please try again.")

def restart_script():
    subprocess.Popen([sys.executable, sys.argv[0]])  # Restart script in a new process
    sys.exit()  # Exit the current script process

def monitor_windows(driver):
    while True:
        try:
            if len(driver.window_handles) == 0:
                print("[Detection] All browser windows are closed. opening profile manager")
                driver.quit()  # Quit WebDriver session
                restart_script()  # Restart the script in a new process
        except WebDriverException as e:
            print(f"WebDriverException occurred: {e}")
            print("[Detection] WebDriver exception checking for windows. expecting error finding windows. opening profile manager.")
            driver.quit()  # Quit WebDriver session
            restart_script()
        time.sleep(1)  # Adjust the interval as needed

def main():
    delete_directory(os.path.join(profiles_dir, ' Session'))
    create_profile(" Session")
    while True:
        print("\nProfile Management Menu:")
        print("1. Create a new profile")
        print("2. Select an existing profile")
        print("3. Modify profile settings")
        print("4. Delete a profile")
        print("5. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            profile_name = input("Enter the new profile name: ")
            create_profile(profile_name)
        elif choice == '2':
            profile_name = select_profile()
            if profile_name:
                run_browser(profile_name)
                break
        elif choice == '3':
            profile_name = select_profile()
            if profile_name:
                modify_profile_settings(profile_name)
        elif choice == '4':
            profile_name = input("Enter the profile name to delete: ")
            delete_profile(profile_name)
        elif choice == '5':
            print("Exiting...")
            break
        else:
            print("Invalid option. Please try again.")

def run_browser(profile_name):
    global driver
    settings = get_profile_settings(profile_name)

    # Configure Chrome options for normal mode and persistence
    chrome_options = Options()
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Initialize Chrome options
    chrome_options = Options()
    profiles_dir = os.path.join(script_dir, "data/profiles")
    profile_dir = os.path.join(profiles_dir, profile_name)
    # Configure Chrome options to set the homepage URL
    chrome_options.add_argument(f"--homepage={settings['homepage']}")
    chrome_options.add_argument(f"--user-data-dir={profile_dir}")
    if 'userAgent' in settings:
        chrome_options.add_argument(f"--user-agent={settings['userAgent']}")
    if settings.get('webdriverautomationdetectionfix', True):
     chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    if settings.get('incognito', False):
     chrome_options.add_argument("--incognito")
    if settings.get('defaultExperiments', True):
     chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
     chrome_options.add_experimental_option('useAutomationExtension', False)

    # Check if default arguments should be used
    if settings.get('useDefaultArguments', True):
        default_arguments = [
            "--disable-gpu",
            "--disable-dev-shm-usage"
        ]
        for arg in default_arguments:
            chrome_options.add_argument(arg)

    # Add custom options from profile settings
    if 'arguments' in settings:
        for arg in settings['arguments']:
            chrome_options.add_argument(arg)
    if settings.get('debugMode', False):
        print("Debug Mode is enabled. You can run code in python console.")
    if not settings.get('enableDevTools', True):
        chrome_options.add_argument("--disable-devtools")

    # Initialize Chrome WebDriver using the ChromeDriverManager
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

    # Open a webpage
    driver.get(settings['homepage'])
    monitor_windows(driver)

    # Keep the browser open
    try:
        while True:
         if settings.get('debugMode', False):
          try:
           eval("PY " + input(os.path.abspath(__file__) + ">"))
          except Exception as e:
            print(e)
    except KeyboardInterrupt:
        print("Exiting...")

    except WebDriverException:
        # Handle WebDriverException which occurs when the browser window is closed
        print("Browser window closed unexpectedly. Exiting...")
    
    finally:
        # Close the browser
        driver.quit()

def cmdquote(argument):
    """
    Parse a string to make it suitable as a command-line argument on Windows.

    Args:
        argument (str): The argument string to parse.

    Returns:
        str: The parsed and formatted argument string.
    """
    if sys.platform.startswith('win'):
        # On Windows, wrap the argument in double quotes and escape any existing double quotes
        return '"' + argument.replace('\\', '\\\\').replace('"', '\\"') + '"'
    else:
        # Default handling (not required for Unix-like systems, which should use shlex.quote())
        return shlex.quote(argument)

def delete_directory(directory_path):
    """
    Deletes a directory and its contents if it exists.

    Args:
        directory_path (str): Path to the directory to delete.
    """
    try:
        if os.path.exists(directory_path):
            shutil.rmtree(directory_path)
    except Exception as e:
        print("")

if __name__ == "__main__":
    main()
