import shutil

def transfer(oldVersionPath, newVersionPath):
 try:
  shutil.copytree(oldVersionPath + "/files/data", newVersionPath + "/files/data")
 except FileNotFoundError as err:
  print(err)
 exit()

fromPath = input("From Where To Transfer? (Path):")
toPath = input("Where To Transfer? (Path):")
transfer(fromPath, toPath)