  var currentVersion = navigator.version
  var currentUserAgent = navigator.userAgent
  navigator.__defineGetter__('userAgent', function() {
    return currentUserAgent + " Super-Diamond-Programing/Newest-release Super-Diamond-Elements/Newest-release"
  });
  navigator.__defineGetter__('version', function() {
    return currentVersion + "Super-Diamond-Programing/Newest-release Super-Diamond-Elements/Newest-release"
  });
  navigator.__defineGetter__('appCodeName', function() {
    return 'Super Diamond';
  });
  navigator.__defineGetter__('WebEngine', function() {
    return 'PyQtWebEngine';
  });
  navigator.__defineGetter__('versions', function() {
    const Versions = {
     toString: function() {
      return "[object SuperDiamondVersions]"
     }
    }
    Versions.Super_Diamond_Porgraming = "Newest-release"
    Versions.Super_Diamond_Elements = "Newest-release"
    for (let i = 0; i < navigator.version.split(" ").length; i++) {
     if(navigator.version.split(" ")[i].startsWith("QtWebEngine/")) {
      Versions.WebEngine = navigator.version.split(" ")[i].split("/")[1]
     }
    }
    for (let i = 0; i < navigator.version.split(" ").length; i++) {
     if(navigator.version.split(" ")[i].startsWith("Chrome/")) {
      Versions.chromium = navigator.version.split(" ")[i].split("/")[1]
     }
    }
    return Versions;
  });