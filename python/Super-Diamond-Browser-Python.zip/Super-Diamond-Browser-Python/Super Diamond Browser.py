import sys
import threading
import code
import subprocess
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QSizePolicy, QLineEdit, QPushButton, QVBoxLayout, QWidget, QTabWidget, QAction, QMenu, QInputDialog, QDockWidget, QTextEdit, QLabel, QListWidget, QHBoxLayout, QFileDialog
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings, QWebEngineProfile, QWebEnginePage
from PyQt5.QtCore import Qt, QUrl
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from PyQt5.QtWidgets import QMessageBox
import base64
import os
import secrets
import json
import random
import hashlib
import requests

runJSScript = "false"

class DevTools(QMainWindow):
    def __init__(self, webbrowser):
        super().__init__(webbrowser)
        self.webbrowser = webbrowser
        central_widget = QWidget()
        layout = QVBoxLayout()
        self.text_edit = QTextEdit()
        layout.addWidget(self.text_edit)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
        execute_button = QPushButton('Execute', self)
        execute_button.clicked.connect(self.execute_javascript)
        layout.addWidget(execute_button)
        self.setWindowTitle("Super Diamond Browser - Devtools")

    def execute_javascript(self):
        js_code = self.text_edit.toPlainText()
        self.webbrowser.javascript(js_code)

    def close(self):
        self.hide()

    def open(self):
        self.show()


class DownloadsManager(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        # Create UI elements
        self.setWindowTitle("Downloads Manager")

        self.downloads_list = QListWidget(self)

        self.clear_button = QPushButton("Clear Downloads", self)
        self.clear_button.clicked.connect(self.clear_downloads)

        self.open_folder_button = QPushButton("Set Download Folder", self)
        self.open_folder_button.clicked.connect(self.set_download_folder)
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Downloads:"))
        layout.addWidget(self.downloads_list)

        buttons_layout = QHBoxLayout()
        buttons_layout.addWidget(self.clear_button)
        buttons_layout.addWidget(self.open_folder_button)
        layout.addLayout(buttons_layout)
        self.download_location = self.readFile("files/download_path.txt")
        self.setLayout(layout)
        profile = QWebEngineProfile.defaultProfile()
        profile.downloadRequested.connect(self.handle_download)

    def calculate_file_hash_from_url(self, file_url, hash_algorithm='sha256', chunk_size=8192):
     hash_function = hashlib.new(hash_algorithm)

     with requests.get(file_url.toString(), stream=True) as response:
        response.raise_for_status()
        for chunk in response.iter_content(chunk_size=chunk_size):
            hash_function.update(chunk)

     return hash_function.hexdigest()

    def scan_file_with_virustotal(self, api_key, file_hash):
     url = f'https://www.virustotal.com/api/v3/files/{file_hash}'
     headers = {'x-apikey': api_key}
     response = requests.get(url, headers=headers)
     result = response.json()
     try:
        total_scans = result["data"]["attributes"]["last_analysis_stats"].get("total", "74 (N/A)")
        malicious_scans = result["data"]["attributes"]["last_analysis_stats"].get("malicious", "N/A")
        print(f'VirusTotal Scan Result: {malicious_scans} / {total_scans}')
     except KeyError as e:
        print(f"Error: Unable to retrieve VirusTotal scan results. KeyError: {e}")
        print("Full result:", result)    

     return result

    def add_download(self, file_name):
        self.downloads_list.addItem(file_name)

    def clear_downloads(self):
        self.downloads_list.clear()

    def set_download_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "Set Download Folder", self.download_location)
        if folder_path:
            self.setFileContent("files/download_path.txt", folder_path)
            self.download_location = folder_path

    def handle_download(self, download):
         file_hash = self.calculate_file_hash_from_url(download.url())
         scanresult = self.scan_file_with_virustotal("16db9cee6f3f3a7e5848bed8f62029020e3e788deab3482df9e62cdb00bf912b", file_hash)
         download.setPath(self.download_location + "/" + os.path.basename(download.path()))
         try:
          self.add_download(os.path.basename(download.path()) + f' ({scanresult["data"]["attributes"]["last_analysis_stats"].get("malicious", "N/A")} / {scanresult["data"]["attributes"]["last_analysis_stats"].get("total", "74 (N/A)")})')
         except KeyError:
          self.add_download(os.path.basename(download.path()))
         download.accept()

    def setFileContent(self, path, content):
            file = open(path, "w")
            file.write(content)
            file.close()

    def readFile(self, file_path):
            file = open(file_path, 'r', encoding='utf-8')
            file_content = file.read()
            file.close()
            return file_content


class WebBrowser(QMainWindow):
    def __init__(self, password_manager):
            super().__init__()

            self.downloadManager = DownloadsManager()
            self.downloadManager.show()
            self.browser_tabs = QTabWidget()
            self.browser_tabs.setTabsClosable(True)
            self.browser_tabs.tabCloseRequested.connect(self.close_tab)

            self.add_new_tab()

            self.container = QWidget()
            self.layout = QVBoxLayout(self.container)

            self.urlbar = QLineEdit()
            self.urlbar.returnPressed.connect(self.navigate_to_url)

            self.browser_tabs.currentChanged.connect(self.handle_tab_change)

            self.new_tab_btn = QPushButton("New Tab")
            self.new_tab_btn.clicked.connect(self.add_new_tab)

            self.search_btn = QPushButton("Go")
            self.search_btn.clicked.connect(self.navigate_to_url)

            self.back_btn = QPushButton("<-")
            self.back_btn.clicked.connect(self.back)

            self.forward_btn = QPushButton("->")
            self.forward_btn.clicked.connect(self.forward)

            self.refresh_btn = QPushButton("↻")
            self.refresh_btn.clicked.connect(self.refresh)
            
            self.layout.addWidget(self.urlbar)
            self.buttonLayout = QHBoxLayout()
            self.buttonLayout.addWidget(self.back_btn)
            self.buttonLayout.addWidget(self.forward_btn)
            self.buttonLayout.addWidget(self.refresh_btn)
            self.buttonLayout.addWidget(self.search_btn)
            self.buttonLayout.addWidget(self.new_tab_btn)
            self.buttonLayoutWidget = QWidget()
            self.buttonLayoutWidget.setLayout(self.buttonLayout)
            self.layout.addWidget(self.buttonLayoutWidget)
            self.layout.addWidget(self.browser_tabs)
            self.bookmarks = []  # Added bookmarks list
            self.bookmarks_menu = QMenu("Bookmarks", self)  # Added bookmarks menu
            self.devtools = DevTools(self)
            self.devtools_menu = QMenu("DevTools", self) 
            open_devtools_action = QAction("Open", self)
            open_devtools_action.triggered.connect(self.open_dev_tools)
            self.devtools_menu.addAction(open_devtools_action)
            close_devtools_action = QAction("Close", self)
            close_devtools_action.triggered.connect(self.devtools.close)
            self.devtools_menu.addAction(open_devtools_action)
            self.menuBar().addMenu(self.devtools_menu)

            self.load_bookmarks()  # Load bookmarks from file

            # Added actions for bookmarks
            add_bookmark_action = QAction("Add Bookmark", self)
            add_bookmark_action.triggered.connect(self.add_bookmark)
            self.bookmarks_menu.addAction(add_bookmark_action)

            show_bookmarks_action = QAction("Show Bookmarks", self)
            show_bookmarks_action.triggered.connect(self.show_bookmarks)
            self.bookmarks_menu.addAction(show_bookmarks_action)

            self.menuBar().addMenu(self.bookmarks_menu)  # Added bookmarks menu to the menu bar

            self.password_manager = password_manager

            # Add buttons for password management
            self.save_password_btn = QPushButton("Save Password")
            self.save_password_btn.clicked.connect(self.save_password_dialog)
            self.show_passwords_btn = QPushButton("Show Passwords")
            self.show_passwords_btn.clicked.connect(self.show_passwords_dialog)

            self.layout.addWidget(self.save_password_btn)
            self.layout.addWidget(self.show_passwords_btn)

            self.setGeometry(100, 100, 1280, 800)
            self.setWindowTitle("Super Diamond Browser")
            self.setCentralWidget(self.container)
            self.setWindowIcon(QIcon("files/icons/icon.ico"))
            self.interval(1, self.checkUserJavascript)
            self.QWebEngineProfile = QWebEngineProfile.defaultProfile()
            self.load_settings()

    def load_settings(self):
            self.QWebEngineProfile.settings().setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
            self.QWebEngineProfile.setPersistentStoragePath("files/data/PersistantStorage")
            self.QWebEngineProfile.setCachePath("files/data/Cache")
            self.QWebEngineProfile.settings().setAttribute(QWebEngineSettings.JavascriptCanOpenWindows, True)
            self.QWebEngineProfile.settings().setAttribute(QWebEngineSettings.PdfViewerEnabled, True)

    def handle_tab_change(self, index):
        current_tab = self.browser_tabs.widget(index)
        self.urlbar.setText(current_tab.url().toString())
        self.urlbar.setCursorPosition(0)
        if current_tab:
            current_tab.page().featurePermissionRequested.connect(self.handle_permission_request)

    def show_passwords_dialog(self):
        passwords_text = self.password_manager.show_passwords()
        if not passwords_text:
            passwords_text = "No passwords saved."
        self.show_dialog("Show Passwords", passwords_text)
        print("Password List\n" + passwords_text)

    def handle_permission_request(self, origin, feature):
        feature_names = {
         QWebEnginePage.Geolocation: "Geolocation",
         QWebEnginePage.MediaAudioCapture: "Microphone",
         QWebEnginePage.MediaVideoCapture: "Camera",
         QWebEnginePage.MediaAudioVideoCapture: "Microphone and Camera",
         QWebEnginePage.DesktopVideoCapture: "Screen View",
         QWebEnginePage.DesktopAudioVideoCapture: "Desktop Audio and Screen View",
         QWebEnginePage.Notifications: "Notification"
        }
        current_tab = self.browser_tabs.currentWidget()
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Question)
        msg.setText(f"Permission Request from {origin.toString()}")
        msg.setInformativeText(f"Do you want to give {origin.toString()} {feature_names.get(feature, '(unknown)')} Permission(s)?")
        msg.setWindowTitle("Permission Request")
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        if msg.exec_() == QMessageBox.Yes:
            current_tab.page().setFeaturePermission(origin, feature, QWebEnginePage.PermissionGrantedByUser)
        elif msg.exec_() == QMessageBox.No:
            current_tab.page().setFeaturePermission(origin, feature, QWebEnginePage.PermissionDeniedByUser)

    def back(self):
        current_tab = self.browser_tabs.currentWidget()
        current_tab.back()

    def forward(self):
        current_tab = self.browser_tabs.currentWidget()
        current_tab.forward()

    def refresh(self):
        current_tab = self.browser_tabs.currentWidget()
        current_tab.reload()

    def save_password_dialog(self):
        service, ok = QInputDialog.getText(self, "Save Password", "Enter service:")
        if ok:
            username, ok = QInputDialog.getText(self, "Save Password", "Enter username:")
            if ok:
                password, ok = QInputDialog.getText(self, "Save Password", "Enter password:")
                if ok:
                    self.password_manager.save_password(service, username, password)
                    self.show_dialog("Password Saved", "Password saved successfully.")

    def open_dev_tools(self):
      self.devtools.open()

    def close_tab(self, index):
     widget = self.browser_tabs.widget(index)
     if widget is not None:
      widget.deleteLater()

    def update_bookmarks_menu(self):
        # Clear the existing bookmarks menu
        self.bookmarks_menu.clear()

        # Populate the menu with the updated list of bookmarks
        for bookmark in self.bookmarks:
            bookmark_action = QAction(bookmark["title"], self)
            bookmark_action.triggered.connect(lambda checked, url=bookmark["url"]: self.navigate_to_bookmark(url))
            self.bookmarks_menu.addAction(bookmark_action)

        # Add actions for managing bookmarks
        self.bookmarks_menu.addSeparator()

        add_bookmark_action = QAction("Add Bookmark", self)
        add_bookmark_action.triggered.connect(self.add_bookmark)
        self.bookmarks_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("Show Bookmarks", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks)
        self.bookmarks_menu.addAction(show_bookmarks_action)

        # Update the menuBar with the new bookmarks menu
        self.menuBar().addMenu(self.bookmarks_menu)

    def show_bookmarks(self):
        self.bookmarks_menu.clear()

        for bookmark in self.bookmarks:
            bookmark_action = QAction(bookmark["title"], self)
            bookmark_action.triggered.connect(lambda checked, url=bookmark["url"]: self.navigate_to_bookmark(url))
            self.bookmarks_menu.addAction(bookmark_action)

        # Additional actions for bookmarks
        add_bookmark_action = QAction("Add Bookmark", self)
        add_bookmark_action.triggered.connect(self.add_bookmark)
        self.bookmarks_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("Show Bookmarks", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks)
        self.bookmarks_menu.addAction(show_bookmarks_action)

        self.menuBar().addMenu(self.bookmarks_menu)

    def load_bookmarks(self):
        try:
            with open("files/data/bookmarks.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()

                for line in lines:
                    # Split the line into title and url
                    parts = line.strip().split(',')

                    # Check if the line has the expected format
                    if len(parts) == 2:
                        bookmark = {"title": parts[0], "url": parts[1]}
                        self.bookmarks.append(bookmark)
                    else:
                        print(f"Skipping invalid line in bookmarks file: {line}")
        except Exception as e:
            print(f"Error loading bookmarks: {e}")

    def navigate_to_bookmark(self, url):
        if url.startswith("javascipt:"):
            javascript(url.lstrip("javascript:"))
        else:
            current_tab = self.browser_tabs.currentWidget()
            current_tab.setUrl(QUrl(url))

    def save_bookmarks(self):
        with open("files/data/bookmarks.txt", "w", encoding="utf-8") as file:
            # Clear the existing content in the file
            file.truncate(0)

            # Write the updated list of bookmarks
            for bookmark in self.bookmarks:
                file.write(f"{bookmark['title']},{bookmark['url']}\n")

    def add_bookmark(self):
        bookmark_url, ok = QInputDialog.getText(self, "Add Bookmark", "Enter bookmark URL:")
        if ok:
            bookmark_title, ok = QInputDialog.getText(self, "Add Bookmark", "Enter bookmark title:")
            if ok:
                bookmark = {"title": bookmark_title, "url": bookmark_url}
                self.bookmarks.append(bookmark)
                self.save_bookmarks()

    def interval(self, time, function):
        def interval_componement():
            while not self.closing:
                eval(function)
                time.sleep(time)

    def timeout(self, time, function):
        def timeout_componement():
            time.sleep(time)
            function()

    def setFileContent(self, path, content):
        def fileEditor():
            file = open(path, "w")
            file.write(content)
            file.close()

    def vbs(self, code):
        def vbs_executor():
            vbs_file = open("files/executors/vbs/execute.vbs", "w")
            vbs_file.write(code)
            vbs_file.close()
            return subprocess.Popen(['cscript', '//nologo', 'files/executors/vbs/execute.vbs'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    def add_new_tab(self):
        new_tab = QWebEngineView()
        new_tab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        new_tab.urlChanged.connect(self.url_change)
        self.browser_tabs.addTab(new_tab, "New Tab")
        new_tab.load(QUrl("about:blank"))
        new_tab.page().featurePermissionRequested.connect(self.handle_permission_request)

    def open_downloadManager(self):
        self.downloadManager = DownloadsManager()

    def checkUserJavascript(self):
        if runJSScript == "true":
            runJSScript = "false"
            Javascript(JSScript)

    def close_tab(self, index):
        widget = self.browser_tabs.widget(index)
        if widget is not None:
            widget.deleteLater()

    def navigate_to_url(self):
        current_tab = self.browser_tabs.currentWidget()
        q = QUrl(self.urlbar.text())
        if current_tab:
            q = QUrl(self.urlbar.text())
            current_tab.setUrl(q)
        else:
            # If no tabs exist, create a new tab and navigate
            self.add_new_tab()
            self.navigate_to_url()

    def url_change(self, q):
        current_tab = self.browser_tabs.currentWidget()
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)
        current_tab.page().runJavaScript("console.log('Page URL changed to:', window.location.href);")
        self.importUserPackages()
        self.loadConfig()
        self.importSuperDiamondPackages()

    def importUserPackages(self):
        try:
            UrlPackages = self.readFile("files/packages/user/url_packages.txt")
            FilePackages = self.readFile("files/packages/user/file_packages.txt")
        except:
            print("Browser ERR: failed to read User Package list files")

        try:
            UrlPackagesArray = UrlPackages.split(",")
            FilePackagesArray = FilePackages.split(",")
        except:
            print("Browser ERR: failed to convert User package lists to arrays")

        try:
            for url in UrlPackagesArray:
                self.javascript(self.source_code(url))

            for packageName in FilePackagesArray:
                self.javascript(self.readFile("files/packages/users/", packageName))
        except:
            print("Browser ERR: failed to run User packages from array")

    def loadConfig(self):
        try:
            self.javascript_from_file("files/config/navigator.js")
        except:
            print("Browser ERR: could not Load Config for Page")

    def importSuperDiamondPackages(self):
        try:
            self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_programing_language.txt")))
            self.javascript(self.source_code(self.readFile("files/packages/system/super_diamond_html_elements.txt")))
        except:
            print("Browser ERR: could not Import Super Diamond Packages")

    def javascript(self, code):
        try:
            return self.browser_tabs.currentWidget().page().runJavaScript(code, javascript_callback)
        except:
            print("Browser ERR: could not run JS From Code")

    def python(self, code):
        try:
            return eval(code)
        except:
            print("Browser ERR: could not run Python From String at self.python(", code, ")")

    def javascript_from_file(self, file_path):
        try:
            js_file = open(file_path, 'r', encoding='utf-8')
            js_code = js_file.read()
            js_file.close()
            page = self.browser_tabs.currentWidget().page()
            return page.runJavaScript(js_code)
        except:
            print("Browser ERR: could not Execute Local File")

    def readFile(self, file_path):
        def fileReader():
            try:
                file = open(file_path, 'r', encoding='utf-8')
                file_content = file.read()
                file.close()
                return file_content
            except:
                print("Super Diamond Browser: Could Not Read File Content from ", file_path)
                self.vbs('x=msgbox("Could Not Read File Content from ', file_path, '" ,0+16, "Super Diamond Browser")')

    def javascript_callback(result):
        print("JavaScript result:", result)

    def quit(self):
        app.quit()

    def loadHomePage(self):
        try:
            fileType = self.readFile("files/homepage/type.txt")
            filePath = "reading..."
            filePath = "file/homepage/home." + fileType
            self.browser_tabs.currentWidget().setUrl(QUrl(filePath))
        except:
            print("Browser ERR: could not load Homepage. showing a blank page")

    def show_dialog(self, title, message):
        dialog = QMessageBox(self)
        dialog.setWindowTitle(title)
        dialog.setText(message)
        dialog.exec_()


class PasswordManager:
    def __init__(self):
        self.files_path = "files/"
        self.key_file_path = "files/data/password-encryption-key.txt"
        self.password_file_path = "files/data/passwords.json"
        self.load_or_generate_key()
        self.cipher_suite = Fernet(self.key)
        self.passwords = {}
        self.load_passwords()
        self.password_file = "files/data/passwords.json"

    def initialize_cipher_suite(self):
        if os.path.isfile(self.key_file_path):
            # Load the key from the file
            with open(self.key_file_path, 'rb') as key_file:
                key = key_file.read()

            # Check key length
            if len(key) != 32:
                print(f"Invalid key length loaded from file: {key}")
                print("Using the loaded key.")
            else:
                print(f"Generated or loaded key from file: {key}")
        else:
            # Generate a new key and save it to the file
            key = Fernet.generate_key()
            with open(self.key_file_path, 'wb') as key_file:
                key_file.write(key)
            print(f"Generated new key and saved to file: {key}")

        return Fernet(key)


    def load_or_generate_key(self):
        key_file_path = os.path.join(self.key_file_path)
        if os.path.exists(key_file_path):
            with open(key_file_path, 'rb') as key_file:
                key = key_file.read()
                self.cipher_suite = Fernet(key)
                self.key = key
                print(f'Loaded key from file: {key}')
                key_file.close()
        else:
            key = Fernet.generate_key()
            with open(key_file_path, 'wb') as key_file:
                key_file.write(key)
                print(f'Generated and saved new key to file: {key}')
                key_file.close()
            self.key = key
            self.cipher_suite = Fernet(key)
            print(f'Using the generated key.')

    def encrypt_password(self, password):
        if isinstance(password, str):
            password_bytes = password.encode()  # Convert the password string to bytes
        elif isinstance(password, bytes):
            password_bytes = password
        else:
            raise ValueError("Password must be either a string or bytes")

        encrypted_password = self.cipher_suite.encrypt(password_bytes)
        print("encrypted password: ", password)
        return encrypted_password


    def decrypt_password(self, encrypted_password):
        return self.cipher_suite.decrypt(encrypted_password).decode()

    def save_password(self, service, username, password):
        # Load existing passwords
        self.load_passwords()

        # Check if the service already exists in passwords
        if service in self.passwords:
            print(f"Service {service} already has a password. Updating...")
        else:
            print(f"Adding new service: {service}")

        # Update or add the entry for the service
        self.passwords[service] = {
            "username": username,
            "password": self.encrypt_password(password)
        }

        # Save the passwords to the file
        self.save_passwords()


    def save_passwords(self):
        # Save passwords to file
        with open(self.password_file, 'w') as file:
            # Convert bytes to string before serializing
            json.dump(self.convert_bytes_to_str(self.passwords), file, indent=4)



    def load_passwords(self):
        try:
            # Check if the file is empty
            if os.path.getsize(self.password_file_path) > 0:
                # Load passwords from file
                with open(self.password_file_path, 'r') as file:
                    self.passwords = self.convert_str_to_bytes(json.load(file))
            else:
                # If file is empty, set passwords to an empty dictionary
                self.passwords = {}
        except FileNotFoundError:
            # If file doesn't exist, create an empty dictionary
            self.passwords = {}

    def show_passwords(self):
        passwords_text = ""
        for service, info in self.passwords.items():
            passwords_text += f"Service: {service}\nUsername: {info['username']}\nPassword: {self.decrypt_password(info['password'])}\n\n"
        return passwords_text

    def convert_bytes_to_str(self, data):
        # Recursively convert bytes to string in a dictionary
        if isinstance(data, bytes):
            return data.decode('utf-8')
        elif isinstance(data, dict):
            return {key: self.convert_bytes_to_str(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [self.convert_bytes_to_str(item) for item in data]
        else:
            return data

    def convert_str_to_bytes(self, data):
        # Recursively convert string to bytes in a dictionary
        if isinstance(data, str):
            return data.encode('utf-8')
        elif isinstance(data, dict):
            return {key: self.convert_str_to_bytes(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [self.convert_str_to_bytes(item) for item in data]
        else:
            return data

def run_console():
    def console_thread():
        console = code.InteractiveConsole(locals=globals())
        console.interact(banner="Browser Console")

    thread = threading.Thread(target=console_thread)
    thread.start()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    password_manager = PasswordManager()
    window = WebBrowser(password_manager)
    window.show()
    run_console()
    sys.exit(app.exec_())
