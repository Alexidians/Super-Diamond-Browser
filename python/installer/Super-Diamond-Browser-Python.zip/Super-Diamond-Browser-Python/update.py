print("loading...")
import requests
import zipfile
import shutil
import os
def install():
 print("starting instalation.")
 try:
  print("copying data to safe location...")
  shutil.copytree('files/data', 'updatetemp/data')

  print("getting newest version")
  newVerRequest = requests.get("https://alexidians.github.io/Super-Diamond-Browser/python/installer/Super-Diamond-Browser-Python.zip")
  if(newVerRequest.status_code == 200):
   print("downloading new version...")
   with open('newver.zip') as file:
    file.write(newVerRequest.text)
    file.close()
   with zipfile.ZipFile('newver.zip', 'r') as zip_ref:
    zip_ref.extractall()
   os.remove("newver.zip")
   print("loading data...")
   shutil.copytree('updatetemp/data', 'files/data')
   print("Sucess")

  else:
   choice = input("Status code while getting version is not 200 (OK) its ", newVerRequest.status_code, " would you still like to update with the status code? (Y/N):")
   if choice == "Y":
    print("downloading new version...")
    with open('newver.zip') as file:
     file.write(newVerRequest.text)
     file.close()
    with zipfile.ZipFile('newver.zip', 'r') as zip_ref:
     zip_ref.extractall()
    os.remove("newver.zip")
    print("loading data...")
    shutil.copytree('updatetemp/data', 'files/data')
    print("Sucess!")
 except e:
  print("Failed: ", e)
  choice = input("retry? (Y/N):")
  if choice == "Y":
   install()