print("loading...")
import requests
import zipfile
import shutil
import os
import io

def update():
 try:
  print("starting update.")
  print("copying data to safe location...")
  shutil.copytree('files/data', 'updatetemp/data')

  print("getting newest version")
  newVerRequest = requests.get("https://alexidians.github.io/Super-Diamond-Browser/python/installer/Super-Diamond-Browser-Python.zip", stream=True)
  if(newVerRequest.status_code == 200):
   print("downloading new version...")
   z = zipfile.ZipFile(io.BytesIO(newVerRequest.content))
   z.extractall()
   os.remove("newver.zip")
   print("loading data...")
   shutil.copytree('updatetemp/data', 'files/data')
   print("clearing update temp...")
   newVerRequest = requests.get("https://alexidians.github.io/Super-Diamond-Browser/python/installer/clear-updatetemp.zip", stream=True)
   z = zipfile.ZipFile(io.BytesIO(newVerRequest.content))
   z.extractall()
   os.remove("updatetemp/delete.txt")
   os.rmdir("updatetemp")
   print("Sucess")

  else:
   choice = input("Status code while getting version is not 200 (OK) its ", newVerRequest.status_code, " would you still like to update with the status code or retry? (Y (update with status_code)/N (retry)):")
   if choice == "Y":
    print("downloading new version...")
    z = zipfile.ZipFile(io.BytesIO(newVerRequest.content))
    z.extractall()
    print("loading data...")
    shutil.copytree('updatetemp/data', 'files/data')
    print("clearing update temp...")
    newVerRequest = requests.get("https://alexidians.github.io/Super-Diamond-Browser/python/installer/clear-updatetemp.zip", stream=True)
    z = zipfile.ZipFile(io.BytesIO(newVerRequest.content))
    z.extractall()
    os.remove("updatetemp/delete.txt")
    os.rmdir("updatetemp")
    print("Sucess")
   else:
    update()
 except:
  print("Failure while updating")
  input("Press Enter to Retry")
  print("Retrying...")
  update()

update()